<?php

namespace room17\SkyBlock\command;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\Player;
use room17\SkyBlock\session\iSession;
use room17\SkyBlock\session\Session;
use room17\SkyBlock\SkyBlock;
use room17\SkyBlock\command\IsleCommand;
use room17\SkyBlock\isle\isle;
use room17\SkyBlock\isle\isleManager;
use room17\SkyBlock\event\isle\IsleCloseEvent;
use room17\SkyBlock\event\isle\IsleDisbandEvent;
use room17\SkyBlock\depend\FormAPI\Form;
use room17\SkyBlock\depend\FormAPI\FormAPI;
use room17\SkyBlock\depend\FormAPI\SimpleForm;
use room17\SkyBlock\depend\FormAPI\ModalForm;
use room17\SkyBlock\depend\FormAPI\CustomForm;

class IsleCommandMap extends Command {
    
    public $playerList = [];
    private $plugin;
    private $form;
    private $commands = [];
    private $isleManager;
    
    public function __construct(SkyBlock $plugin) {
        $this->plugin = $plugin;
        parent::__construct("sb", "Open menu SkyBlock!", "usage: /sb", ["skyblock", "sbui", "skyblockui"]);
        $plugin->getServer()->getCommandMap()->register("sb", $this);
    }
    
    public function getPlugin(): SkyBlock {
        return $this->plugin;
    }
    
    public function getCommands(): array {
        return $this->commands;
    }
    
    public function getCommand(string $alias): ?IsleCommand {
        foreach($this->commands as $key => $command) {
            if(in_array(strtolower($alias), $command->getAliases()) or $alias == $command->getName()) {
                return $command;
            }
        }
        return null;
    }
    
    public function registerCommand(IsleCommand $command) {
        $this->commands[] = $command;
    }
    
    public function execute(CommandSender $sender, string $commandLabel, array $args): void {
        if(!$sender instanceof Player) {
            $sender->sendMessage("Please, run this command in game");
            return;
        }
        
        $session = $this->plugin->getSessionManager()->getSession($sender);
        if($session->hasIsle()) {
            $this->Menu($sender);
        }else{
            $this->Buat($sender);
        }
    }
    public function Information($sender){
        $form = new SimpleForm(function(Player $sender, $data){
            $result = $data;
            if($result === null){
                return true;
            }
            switch($result){
                case 0:
                    $this->Menu($sender);
                break;
            }
        });
        $form->setTitle("§3Island Info");
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $island = $session->getIsle();
        $isMembers = count($island->getMembers());
        $content = "§fBelow is your island info\n\n";
        $content .= "§eBlocks§f: §a" . $island->getBlocksBuilt() . "\n\n";
        $content .= $island->isLocked() ? "§eState§f: §cLocked\n\n" : "§eState§f: §aUnlocked\n\n";
        $content .= "§eMembers§f: §a" . $isMembers . "§f/§a" . $island->getSlots() . "\n\n";
        $content .= "§eOnline Members§f: §a" . count($island->getMembersOnline()) . "§f/§a" . $isMembers . "\n\n";
        $content .= "§eCategory§f: §a" . $island->getCategory() . "\n\n";
        $form->setContent($content);
        $form->addButton("§cBack", 0, "textures/ui/back_button_hover");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Create($sender){
        $form = new SimpleForm(function(Player $sender, $data){
            $result = $data;
            if($result === null){
                return true;
            }
            switch($result){
                case 0:$session = $this->plugin->getSessionManager()->getSession($sender);
                    if($session->hasIsle()){
                        $session->sendTranslatedMessage("NEED_TO_BE_FREE");
                        return;
                    }
                    $generator = "Basic";
                    if($this->plugin->getGeneratorManager()->isGenerator($generator)){
                        $this->plugin->getIsleManager()->createIsleFor($session, $generator);
                        $session->sendTranslatedMessage("SUCCESSFULLY_CREATED_A_ISLE");
                    }else{
                        $session->sendTranslatedMessage("NOT_VALID_GENERATOR", [
                            "name" => $generator
                            ]);
                    }
                break;
                case 1:$session = $this->plugin->getSessionManager()->getSession($sender);
                    if($session->hasIsle()){
                        $session->sendTranslatedMessage("NEED_TO_BE_FREE");
                        return;
                    }
                    $generator = "Shelly";
                    if($this->plugin->getGeneratorManager()->isGenerator($generator)){
                        $this->plugin->getIsleManager()->createIsleFor($session, $generator);
                        $session->sendTranslatedMessage("SUCCESSFULLY_CREATED_A_ISLE");
                    }else{
                        $session->sendTranslatedMessage("NOT_VALID_GENERATOR", [
                            "name" => $generator
                            ]);
                    }
                break;
                case 2: $session = $this->plugin->getSessionManager()->getSession($sender);
                    if($session->hasIsle()){
                        $session->sendTranslatedMessage("NEED_TO_BE_FREE");
                        return;
                    }
                    $generator = "Lost";
                    if($this->plugin->getGeneratorManager()->isGenerator($generator)){
                        $this->plugin->getIsleManager()->createIsleFor($session, $generator);
                        $session->sendTranslatedMessage("SUCCESSFULLY_CREATED_A_ISLE");
                    }else{
                        $session->sendTranslatedMessage("NOT_VALID_GENERATOR", [
                            "name" => $generator
                            ]);
                    }
                break;
                case 3:$session = $this->plugin->getSessionManager()->getSession($sender);
                    if($session->hasIsle()){
                        $session->sendTranslatedMessage("NEED_TO_BE_FREE");
                        return;
                    }
                    $generator = "Palm";
                    if($this->plugin->getGeneratorManager()->isGenerator($generator)){
                        $this->plugin->getIsleManager()->createIsleFor($session, $generator);
                        $session->sendTranslatedMessage("SUCCESSFULLY_CREATED_A_ISLE");
                    }else{
                        $session->sendTranslatedMessage("NOT_VALID_GENERATOR", [
                            "name" => $generator
                            ]);
                    }
                break;
                case 4:
                    $this->Buat($sender);
                break;
            }
        });
        $name = $sender->getName();
        $form->setTitle("§3Create Island");
        $form->setContent("§bHai§e {$name}! §fBelow is island list click whatever island you want");
        $form->addButton("§2Basic Island");
        $form->addButton("§2Shelly Island");
        $form->addButton("§2Lost Island");
        $form->addButton("§2Palm Island");
        $form->addButton("§cBack", 0, "textures/ui/back_button_hover");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Buat($sender){
        $form = new SimpleForm(function(Player $sender, $data){
            $result = $data;
            if($result === null){
                return true;
            }
            if($result === 0){
                $this->Create($sender);
            }
            if($result === 1){
                $this->Accept($sender);
            }
        });
        $name = $sender->getName();
        $form->setTitle("§3SkyBlock Menu");
        $form->setContent("§bHai§e {$name}, §fYou not have island click button below what you want §2Create §fIsland or §aAccept §fInvite!");
        $form->addButton("§2Create §fIsland", 0, "textures/ui/icon_recipe_nature");
        $form->addButton("§aAccept §fInvite", 0, "textures/ui/FriendsIcon");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Menu($sender){
        $form = new SimpleForm(function(Player $sender, $data){
            $result = $data;
            if($result === null){
                return true;
            }
            switch($result){
                case 0:
                    $session = $this->plugin->getSessionManager()->getSession($sender);
                    $session->getPlayer()->teleport($session->getIsle()->getLevel()->getSpawnLocation());
                    $session->sendTranslatedMessage("TELEPORTED_TO_ISLE");
                break;
                case 1:
                    $this->Visit($sender);
                break;
                case 2:
                    $this->Information($sender);
                break;
                case 3:
                    $this->Settings($sender);
                break;
                case 4:
                    $this->Remove($sender);
                break;
                case 5:
                break;
            }
        });
        $name = $sender->getName();
        $form->setTitle("§3SkyBlock Menu");
        $form->setContent("\n");
        $form->addButton("§9Teleport §fIsland", 0, "textures/ui/icon_recipe_nature");
        $form->addButton("§2Visit §fIsland", 0, "textures/ui/spyglass_flat");
        $form->addButton("§eIsland §fInfo", 0, "textures/ui/creative_icon");
        $form->addButton("§3Manage §fIsland", 0, "textures/ui/settings_glyph_color_2x");
        $form->addButton("§4Remove §fIsland", 0, "textures/ui/trash");
        $form->addButton("§cCancel", 0, "textures/ui/cancel");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Visit($sender){
        $list = [];
        foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
            $list[] = $p->getName();
        }
        $this->playerList[$sender->getName()] = $list;
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $form = new CustomForm(function(Player $sender, $data){
            if($data === null){
                return true;
            }
            $index = $data[0];
            $playerName = $this->playerList[$sender->getName()][$index];
            $session = $this->plugin->getSessionManager()->getSession($sender);
            $offline = $this->plugin->getSessionManager()->getOfflineSession($playerName);
            $isleId = $offline->getIsleId();
            if($isleId == null) {
                $session->sendTranslatedMessage("HE_DO_NOT_HAVE_AN_ISLE", [
                "name" => $playerName
                ]);
                return;
            }
            $this->plugin->getProvider()->loadIsle($isleId);
            $isle = $this->plugin->getIsleManager()->getIsle($isleId);
            if($isle->isLocked()) {
                $session->sendTranslatedMessage("HIS_ISLE_IS_LOCKED", [
                    "name" => $playerName
                ]);
                $isle->tryToClose();
                return;
            }
            $session->getPlayer()->teleport($isle->getLevel()->getSpawnLocation());
            $session->sendTranslatedMessage("VISITING_ISLE", [
                "name" => $playerName
                ]);
        });
        $form->setTitle("§3Visit");
        $form->addDropDown("§fSelect a Player!", $this->playerList[$sender->getName()]);
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Settings($sender){
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $form = new SimpleForm(function(Player $sender, $data){
            $result = $data;
            if($result === null){
                return true;
            }
            switch($result){
                case 0:
                    $session = $this->plugin->getSessionManager()->getSession($sender);
                    if($this->checkLeader($session)) {
                        return;
                    }
                    $isle = $session->getIsle();
                    $isle->setLocked(!$isle->isLocked());
                    $isle->save();
                    $session->sendTranslatedMessage($isle->isLocked() ? "ISLE_LOCKED" : "ISLE_UNLOCKED");
                break;
                case 1:
                    $session = $this->plugin->getSessionManager()->getSession($sender);
                    if($this->checkOfficer($session)) {
                        return;
                    } elseif($session->getPlayer()->getLevel() !== $session->getIsle()->getLevel()) {
                        $session->sendTranslatedMessage("MUST_BE_IN_YOUR_ISLE");
                    } else {
                        $session->getIsle()->setSpawnLocation($session->getPlayer());
                        $session->sendTranslatedMessage("SUCCESSFULLY_SET_SPAWN");
                    }
                break;
                case 2:
                    $session = $this->plugin->getSessionManager()->getSession($sender);
                    if($this->checkIsle($session)) {
                        return;
                    }
                    $session->setInChat(!$session->isInChat());
                    $session->sendTranslatedMessage($session->isInChat() ? "JOINED_ISLE_CHAT" : "JOINED_GLOBAL_CHAT");
                    $this->Settings($sender);
                break;
                case 3:
                    $this->Invite($sender);
                break;
                case 4:
                    $this->Kick($sender);
                break;
                case 5:
                    $session = $this->plugin->getSessionManager()->getSession($sender);
                    if($this->checkIsle($session)){
                        return;
                    }elseif($session->getRank() == iSession::RANK_FOUNDER){
                        $session->sendTranslatedMessage("FOUNDER_CANNOT_LEAVE");
                        return;
                    }
                    $session->setRank(iSession::RANK_DEFAULT);
                    $session->setIsle(null);
                    $session->setInChat(false);
                    $session->sendTranslatedMessage("LEFT_ISLE");
                break;
                case 6:
                    $this->Menu($sender);
                break;
            }
        });
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $isle = $session->getIsle();
        $form->setTitle("§3Manage Island");
        $form->setContent("\n");
        if($isle->isLocked()){
            $form->addButton("§cIsland Locked", 0, "textures/ui/icon_lock");
        }else{
            $form->addButton("§2Island Unlocked", 0, "textures/ui/icon_unlocked");
        }
        $form->addButton("§eMake Spawn", 0, "textures/ui/absorption_effect");
        if($session->isInChat()){
            $form->addButton("§3Island Chat\n§lOn", 0, "textures/ui/mute_on");
        }else{
            $form->addButton("§3Island Chat\n§lOff", 0, "textures/ui/mute_off");
        }
        $form->addButton("§2Invite §fFriend", 0, "textures/ui/FriendsIcon");
        $form->addButton("§cKick §fFriend", 0, "textures/ui/FriendsIcon");
        $form->addButton("§cLeave §fIsland", 0, "textures/ui/FriendsIcon");
        $form->addButton("§4Back", 0, "textures/ui/back_button_hover");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Remove($sender){
        $form = new SimpleForm(function(Player $sender, $data){
            $result = $data;
            if($result === null){
                return true;
            }
            switch($result){
                case 0:
                    $session = $this->plugin->getSessionManager()->getSession($sender);
                    if($this->checkFounder($session)) {
                        return;
                    }
                    $this->disbandIsle($session->getIsle());
                break;
                case 1:
                    $this->Settings($sender);
                break;
            }
        });
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $block = $session->getIsle()->getBlocksBuilt();
        $form->setTitle("§3Remove");
        $form->setContent("§cAre you sure you want delete your island?");
        $form->addButton("§cYes", 0, "textures/ui/icon_trash");
        $form->addButton("§2No", 0, "textures/ui/back_button_hover");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Accept($sender){
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $form = new CustomForm(function(Player $sender, $data){
            if($data === null){
                return true;
            }
            $session = $this->plugin->getSessionManager()->getSession($sender);
            if($session->hasIsle()) {
                $session->sendTranslatedMessage("NEED_TO_BE_FREE");
                return;
            } elseif(!isset($data[0]) and !$session->hasLastInvitation()) {
                $session->sendTranslatedMessage("ACCEPT_USAGE");
                return;
            }
            $isle = $session->getInvitation($data[0] ?? $session->getLastInvitation());
            if($isle == null) {
                return;
            }
            $session->setRank(iSession::RANK_DEFAULT);
            $session->setIsle($isle);
            $isle->broadcastTranslatedMessage("PLAYER_JOINED_THE_ISLE", [
                "name" => $session->getUsername()
                ]);
        });
        $form->setTitle("§3Accept");
        $form->addInput("Enter the name of the player who wants to invite his island", "Inviter!");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Invite($sender){
        $list = [];
        foreach($this->plugin->getServer()->getOnlinePlayers() as $p){
            $list[] = $p->getName();
        }
        $this->playerList[$sender->getName()] = $list;
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $form = new CustomForm(function(Player $sender, $data){
            if($data === null){
                return true;
            }
            $index = $data[0];
            $playerName = $this->playerList[$sender->getName()][$index];
            $session = $this->plugin->getSessionManager()->getSession($sender);
            if($this->checkOfficer($session)) {
            return;
        } elseif(!isset($playerName)) {
            $session->sendTranslatedMessage("INVITE_USAGE");
            return;
        } elseif(count($session->getIsle()->getMembers()) >= $session->getIsle()->getSlots()) {
            $isle = $session->getIsle();
            $next = $isle->getNextCategory();
            if($next != null) {
                $session->sendTranslatedMessage("ISLE_IS_FULL_BUT_YOU_CAN_UPGRADE", [
                    "next" => $next
                ]);
            } else {
                $session->sendTranslatedMessage("ISLE_IS_FULL");
            }
            return;
        }
        $player = $this->plugin->getServer()->getPlayer($playerName);
        if($player == null) {
            $session->sendTranslatedMessage("NOT_ONLINE_PLAYER", [
                "name" => $playerName
            ]);
            return;
        }
        $playerSession = $this->plugin->getSessionManager()->getSession($player);
        if($this->checkClone($session, $playerSession)) {
            return;
        } elseif($playerSession->hasIsle()) {
            $session->sendTranslatedMessage("CANNOT_INVITE_BECAUSE_HAS_ISLE", [
                "name" => $player->getName()
            ]);
            return;
        }
        $playerSession->addInvitation($session->getUsername(), $session->getIsle());
        $playerSession->sendTranslatedMessage("YOU_WERE_INVITED_TO_AN_ISLE", [
            "name" => $session->getUsername()
        ]);
        $session->sendTranslatedMessage("SUCCESSFULLY_INVITED", [
            "name" => $player->getName()
        ]);
        });
        $form->setTitle("§3Invite Friend");
        $form->addDropDown("Select one player!", $this->playerList[$sender->getName()]);
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function Kick($sender){
        $session = $this->plugin->getSessionManager()->getSession($sender);
        $form = new CustomForm(function(Player $sender, $data){
            if($data === null){
                return true;
            }
            $session = $this->plugin->getSessionManager()->getSession($sender);
            if($this->checkOfficer($session)) {
                return;
            } elseif(!isset($data[0])) {
                $session->sendTranslatedMessage("KICK_USAGE");
                return;
            }
            $server = $this->plugin->getServer();
            $player = $server->getPlayer($data[0]);
            if($player == null) {
                $session->sendTranslatedMessage("NOT_ONLINE_PLAYER", [
                    "name" => $data[0]
                    ]);
                    return;
            }
            $playerSession = $this->plugin->getSessionManager()->getSession($player);
            if($this->checkClone($session, $playerSession)) {
                return;
            } elseif($playerSession->getIsle() === $session->getIsle()) {
                $session->sendTranslatedMessage("CANNOT_KICK_A_MEMBER");
            } elseif(in_array($player, $session->getIsle()->getPlayersOnline())) {
                $player->teleport($server->getDefaultLevel()->getSpawnLocation());
                $playerSession->sendTranslatedMessage("KICKED_FROM_THE_ISLE");
                $session->sendTranslatedMessage("YOU_KICKED_A_PLAYER", [
                    "name" => $playerSession->getUsername()
                    ]);
            } else {
                $session->sendTranslatedMessage("NOT_A_VISITOR", [
                    "name" => $playerSession->getUsername()
                    ]);
            }
        });
        $form->setTitle("§3Kick Player");
        $form->addInput("Enter player name", "Has to be online!");
        $form->sendToPlayer($sender);
        return $form;
    }
    
    public function checkIsle(Session $session): bool {
        if($session->hasIsle()) {
            return false;
        }
        $session->sendTranslatedMessage("NEED_ISLE");
        return true;
    }
    
    public function checkFounder(Session $session): bool {
        if($this->checkIsle($session)) {
            return true;
        } elseif($session->getRank() == iSession::RANK_FOUNDER) {
            return false;
        }
        $session->sendTranslatedMessage("MUST_BE_FOUNDER");
        return true;
    }
    
    public function checkLeader(Session $session): bool {
        if($this->checkIsle($session)) {
            return true;
        } elseif($session->getRank() == iSession::RANK_FOUNDER or $session->getRank() == iSession::RANK_LEADER) {
            return false;
        }
        $session->sendTranslatedMessage("MUST_BE_LEADER");
        return true;
    }
    
    public function checkOfficer(Session $session): bool {
        if($this->checkIsle($session)) {
            return true;
        } elseif($session->getRank() != iSession::RANK_DEFAULT) {
            return false;
        }
        $session->sendTranslatedMessage("MUST_BE_OFFICER");
        return true;
    }
    
    public function checkClone(?Session $session, ?Session $ySession): bool {
        if($session === $ySession) {
            $session->sendTranslatedMessage("CANT_BE_YOURSELF");
            return true;
        }
        return false;
    }
    
    public function disbandIsle(Isle $isle): void {
        foreach($isle->getLevel()->getPlayers() as $player) {
            $player->teleport($player->getServer()->getDefaultLevel()->getSpawnLocation());
        }
        foreach($isle->getMembers() as $offlineMember) {
            $onlineSession = $offlineMember->getSession();
            if($onlineSession != null) {
                $onlineSession->setIsle(null);
                $onlineSession->setRank(Session::RANK_DEFAULT);
                $onlineSession->save();
                $onlineSession->sendTranslatedMessage("ISLE_DISBANDED");
            } else {
                $offlineMember->setIsleId(null);
                $offlineMember->setRank(Session::RANK_DEFAULT);
                $offlineMember->save();
            }
        }
        $isle->setMembers([]);
        $isle->save();
        $this->closeIsle($isle);
        $this->plugin->getServer()->getPluginManager()->callEvent(new IsleDisbandEvent($isle));
    }
    
    public function closeIsle(Isle $isle): void {
        $isle->save();
        $server = $this->plugin->getServer();
        $server->getPluginManager()->callEvent(new IsleCloseEvent($isle));
        $server->unloadLevel($isle->getLevel());
        unset($this->isles[$isle->getIdentifier()]);
    }
}